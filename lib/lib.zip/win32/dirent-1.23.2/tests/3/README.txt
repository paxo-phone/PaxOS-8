This directory contains some random files for the t-scandir test program.  The
files are empty and only the file names matter.

